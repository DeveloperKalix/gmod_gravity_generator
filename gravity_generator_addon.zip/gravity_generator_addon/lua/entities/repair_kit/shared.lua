ENT.Type = "anim"

ENT.Base = "base_gmodentity"
ENT.PrintName = "Generator Repair Kit"
ENT.Spawnable = true 
ENT.Category = "Ardent Development - Gravity Generator Addon"