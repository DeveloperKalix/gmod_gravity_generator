AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")

include("shared.lua")

local timeElapsed = 600
local degredation = 900


function ENT:Initialize()

    self:SetModel("models/myproject/mesh_0989.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()

    self.isDamaged  = false
    self.gravityDisrupted = false
    self.integrity = 1000
    self.power = 1000
    self.isIgnited = false
    self.needsRepair = false
    self.timer = CurTime()
    
        if(phys:IsValid()) then 
        phys:Wake()

    end
end

function ENT:StartTouch(ent)

    if(ent:GetClass() == "fuel_cell") and self.power < 1000 then 
        ent:Remove()
        local refuel = 200
        refuel = refuel + self.power
        if(refuel >= 1000) then 
            self.power = 1000
            PrintMessage(HUD_PRINTTALK, "[Generator System Notification]: The Gravity Generator's power has been fully restored.")
            ent:GetOwner():addMoney(300)
            ent:GetOwner():ChatPrint("For refueling the Gravity Generator, you have received $" ..300 .. ".")
        else
            self.power = refuel
        end
    end
    if(ent:GetClass() == "repair_kit") and self.integrity < 1000 then
        ent:Remove()
        local outcome = math.random(100)
        if(outcome >= 40) then
            self.integrity  = 1000
            PrintMessage(HUD_PRINTTALK, "[Generator System Notification]: The Gravity Generator's integrity has been fully restored.")
            self.IsIgnited = false
            self:Extinguish()
            for _, ply in pairs(player.GetAll()) do
                ply:SetGravity(1)
            end
            ent:GetOwner():addMoney(500)
            ent:GetOwner():ChatPrint("For repairing the Gravity Generator, you have received $" ..500 .. ".")
        else
            self.integrity = self.integrity + (1000-self.integrity)/2
            PrintMessage(HUD_PRINTTALK, "[Generator System Notification]: The Gravity Generator requires further repairs.")
        end
    end
    if(ent:GetClass() == "repair_kit") and self.integrity == 1000 then
        PrintMessage(HUD_PRINTTALK, "Generator System Notification: The Gravity Generator does not require maintenance at this time.")
    end
    if(ent:GetClass() == "sabotage_device") then
        ent:Remove()
        self.integrity = 150
        self:Ignite(10000)
        self.IsIgnited = true
        PrintMessage(HUD_PRINTTALK, "[Gravity Generator Systems]: The Gravity Generator has been compromised. Temperature levels are rising and gravity level is destabalizing!")
        for _, ply in pairs(player.GetAll()) do
            ply:SetGravity(0.25)
        end
    end
end

function ENT:Think()

    if CurTime() > (self.timer + timeElapsed) then
        self.timer = CurTime()
        if(self.power >= 0) then
            self.power = self.power - 100
            if(self.power < 0) then
                self.power = 0
            end
            -- self:SetMoneyAmount(self:GetMoneyAmount() + 100)
        end
    end

    if(self.integrity < 250 and  not self.IsIgnited) then
        
        self:Ignite(10000)
        self.IsIgnited = true
        PrintMessage(HUD_PRINTTALK, "[Gravity Generator Systems]: The Gravity Generator has been compromised. Temperature levels are rising and gravity level is destabalizing!")
        for _, ply in pairs(player.GetAll()) do
            ply:SetGravity(0.25)
        end
    end
   

end

function ENT:OnTakeDamage(dmginfo)

    self.integrity = self.integrity - dmginfo:GetDamage()
    local attacker = dmginfo:GetAttacker()
    -- if(IsValid(attacker) and attacker:IsPlayer()) then
    --     print("THE GENERATOR TOOK " ..dmgTaken .." from " ..attacker:Nick())
    -- end
    if(self.integrity < 0) then
        self.integrity = 0
    end
end

local printed = false

function ENT:Use(activator, caller)
    if not (printed) then
        PrintMessage(HUD_PRINTTALK, "The integrity of the Gravity Generator is: " ..(self.integrity/1000)*100 .."%.")
        PrintMessage(HUD_PRINTTALK, "The Gravity Generator currently has " ..(self.power/1000)*100 .."% power.")

        printed = true
        timer.Simple(2, function()
            printed = false
        end)
    end
    repairman = activator
end

function ENT:OnRemove()
    for _, ply in pairs(player.GetAll()) do
        ply:SetGravity(1)
    end
end

function ENT:OnUndo()
    for _, ply in pairs(player.GetAll()) do
        ply:SetGravity(1)
    end
end





