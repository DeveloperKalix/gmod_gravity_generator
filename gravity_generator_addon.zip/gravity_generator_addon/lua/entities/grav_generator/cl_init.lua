include("shared.lua")

surface.CreateFont("genFont", {
    font = "Ubuntu-B.ttf",
    size = 72,
    weight = 500,
    blursize = 0,
    scanlines = 0, 
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
})

function ENT:Draw()
    
    self:DrawModel()
    local pos = self:GetPos()
    local ang = self:GetAngles()
    local viewAngles = LocalPlayer():EyeAngles()
    ang:RotateAroundAxis(ang:Right(), 180)
    ang:RotateAroundAxis(ang:Forward(), 90)
    ang:RotateAroundAxis(ang:Up(), 180)
    

    local textOffset = Vector(0, 0, 10) -- Adjust the offset as needed to move the text above the prop
    local textPos = pos + textOffset

    -- Rotate the text to face the player
    local textAngle = Angle(0, viewAngles.y - 90, 90)
   

    -- Set up drawing parameters (font, size, color, etc.)
    local font = "genFont" -- Use any available font here or the one you registered using surface.CreateFont
    local textSize = 30
    local textColor = Color(223, 184, 86)
    local text = "Gravity Generator"

    -- Draw the text above the entity
    cam.Start3D2D(textPos, textAngle, 0.5)
        draw.DrawText(text, font, 0, -400, textColor, TEXT_ALIGN_CENTER, 1, 1)
    cam.End3D2D()

end

-- local function DistanceBetween(ply, entity)
--     if(not IsValid(ply) or not IsValid(entity)) then return end

--     local plyPos = ply:GetPos()
--     local entityPos = entity:GetPos()

--     local distance = plyPos:Distance(entityPos)
--     return distance
-- end