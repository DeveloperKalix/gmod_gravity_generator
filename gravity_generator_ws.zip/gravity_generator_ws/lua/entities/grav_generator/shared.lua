ENT.Type = "anim"

ENT.Base = "base_gmodentity"
ENT.PrintName = "Gravity Generator"
ENT.Spawnable = true 
ENT.Category = "Ardent Development - Gravity Generator Addon"

function ENT:SetupDataTables()
    self:NetworkVar("Int", 1, "Integrity")
end