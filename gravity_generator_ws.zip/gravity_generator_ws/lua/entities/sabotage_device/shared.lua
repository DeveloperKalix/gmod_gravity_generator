ENT.Type = "anim"

ENT.Base = "base_gmodentity"
ENT.PrintName = "Sabotage Device"
ENT.Spawnable = true 
ENT.Category = "Ardent Development - Gravity Generator Addon"

